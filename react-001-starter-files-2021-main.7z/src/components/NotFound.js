import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h2>The Page is Not Found</h2>
        </div>
    )
}

export default NotFound;